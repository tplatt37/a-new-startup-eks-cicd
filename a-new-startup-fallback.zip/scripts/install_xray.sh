#!/bin/bash
#
# From: https://docs.aws.amazon.com/xray/latest/devguide/xray-daemon-ec2.html
#
curl https://s3.us-east-2.amazonaws.com/aws-xray-assets.us-east-2/xray-daemon/aws-xray-daemon-3.x.rpm -o /home/ec2-user/xray.rpm
yum install -y /home/ec2-user/xray.rpm

# You can check if it is running using (it's a systemd unit)
systemctl status xray