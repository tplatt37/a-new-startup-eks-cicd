# A-New-Startup Sample App for AWS Demos

This is a simple, yet realistic, demo application meant for use with various AWS services.  It is a Work In Progress, see TODO.md for outstanding items.

This app is based off of the Elastic Beanstalk Express Sample App: https://github.com/aws-samples/eb-node-express-sample

It is a simple app, but has enough complexity to show off DevOps services and techniques.

For example, it requires a DynamoDB table, an SNS Topic, and includes unit-tests (via Jest)

This version is compatible with multiple deployment methods, including:
EC2 (via CodeDeploy or User Data)
AWS Elastic Beanstalk (includes .ebextensions folder)
AWS Proton (includes svc-spec.yml)
Containers (includes Dockerfile)
...
and more

It uses NodeJS, Express, Bootstrap, so the tech stack resembles that of many modern web apps.

# What the App Does
This sample application uses the [Express](https://expressjs.com/) framework and [Bootstrap](http://getbootstrap.com/) to build a simple, scalable customer signup form that is deployed to [AWS Elastic Beanstalk](http://aws.amazon.com/elasticbeanstalk/). The application stores data in [Amazon DynamoDB](http://aws.amazon.com/dynamodb/) and publishes notifications to the [Amazon Simple Notification Service (SNS)](http://aws.amazon.com/sns/) when a customer fills out the form.
